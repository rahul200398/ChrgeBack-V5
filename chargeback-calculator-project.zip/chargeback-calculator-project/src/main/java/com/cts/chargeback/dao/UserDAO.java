package com.cts.chargeback.dao;

import java.util.List;

import com.cts.chargeback.entity.*;

public interface UserDAO  {
	public void saveUser(User user);
	
	
	

}
